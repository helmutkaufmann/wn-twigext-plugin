<?php 

$filters += [
        
	// Additional fsenameilters
      		
	'basename' => 'basename',
	
	'dirname' => 'dirname',
	
	'addslashes' => function ($file) {
		return addslashes($file);
	},

	'bin2hex' => function ($string) {
		return bin2hex($string);
	},

	'hex2bin' => function ($string) {
		return hex2bin($string);
	},

	'urlencode' => function ($string) {
		return urlencode($string) ;
	},

	'htmlspecialchars' => function ($string) {
		return htmlspecialchars($string) ;
	},

	'urldecode' => function ($string) {
		return urldecode($string);
	},

	'base64_encode' => function ($string) {
		return base64_encode($string);
	},

	'base64_decode' => function ($string) {
		return base64_decode($string);
	},
	
	'shuffle' => function($array) {
		$temparray=$array;
		shuffle($temparray);
		return $temparray;
	}

]

?>

