<?php


$functions += [

	//
	// Array
	//
	'preg_grep' => function ($array, $pattern, $flags = 0) {
		return preg_grep ($pattern, $array, $flags);
	},


];

?>
