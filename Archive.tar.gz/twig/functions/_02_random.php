<?php

$functions += [

	//
	// RANDOM BYTES
	'randomBytes' => function (int $length) {
			return random_bytes($length);
	},

];

?>
